import React, {useEffect, useState, useContext} from 'react';
import {useNavigate} from 'react-router-dom';
import {Modal, Button, Alert} from 'react-bootstrap';
import {useAuth} from './users/auth'; // Adjust the import path
import axios from 'axios';

interface Author {
    username: string;
    profile_pic?: string;
}

interface Post {
    id: number;
    title: string;
    content: string;
    author: Author;
    image?: string;
}


const Home: React.FC = () => {
    const [posts, setPosts] = useState<Post[]>([]);
    const [messages, setMessages] = useState<string[]>([]);
    const {isAuthenticated} = useAuth();
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [image, setImage] = useState<File | null>(null);
    const navigate = useNavigate();
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault(); // Prevent default form submission

        const formData = new FormData();
        formData.append('title', title);
        formData.append('content', content);
        if (image) formData.append('image', image);

        try {
            // Adjust the URL to your API endpoint for creating a post
            const response = await axios.post('http://localhost:8000/api/post/new', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            // Handle response...
            console.log(response.data);
        } catch (error) {
            console.error('Error creating post:', error);
        }
    };

    useEffect(() => {
        const fetchPosts = async () => {
            const token = sessionStorage.getItem('token'); // or localStorage
            console.log("Token:", token); // For debugging

            if (token) {
                axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
            }

            const config = {
                headers: {Authorization: `Bearer ${token}`},
            };

            try {
                const {data} = await axios.get('http://localhost:8000/api/posts', config);
                setPosts(data);
            } catch (error) {
                console.error('Error fetching posts:', error);
            }
        };

        fetchPosts();
    }, []);


    const fetchPosts = async () => {
        // Implement fetching posts from your API
    };

    return (
        <div className="container">
            <div className="text-center">
                {messages.map((message, index) => (
                    <Alert key={index} variant="success" dismissible>
                        {message}
                    </Alert>
                ))}
            </div>

            {isAuthenticated && (
                <div className="body-create-post">
                    <div className="container mt-5">
                        <div className="row justify-content-center">
                            <div className="col-md-6">
                                <div className="form-create-post">
                                    <h1 className="text-center">Create New Post</h1>
                                    <form method="post" className="m-3" onSubmit={handleSubmit}
                                          encType="multipart/form-data">
                                        <div className="form-group mt-2">
                                            <input
                                                type="text"
                                                className="form-control"
                                                id="title"
                                                name="title"
                                                placeholder="Enter title"
                                                required
                                                value={title}
                                                onChange={(e) => setTitle(e.target.value)}
                                            />
                                        </div>
                                        <div className="form-group mt-2">
                                    <textarea
                                        className="form-control"
                                        id="content"
                                        name="content"
                                        rows={5}
                                        placeholder="What is on your mind..."
                                        required
                                        value={content}
                                        onChange={(e) => setContent(e.target.value)}
                                    />
                                        </div>
                                        <div className="form-group mt-2">
                                            <input
                                                type="file"
                                                className="form-control"
                                                id="image"
                                                name="image"
                                                onChange={(e) => setImage(e.target.files ? e.target.files[0] : null)}
                                            />
                                        </div>
                                        <div className="text-center mt-2">
                                            <button type="submit" className="btn btn-light">
                                                <i className="fas fa-paper-plane"></i> Publish
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <div className="posts-container">
                {posts.length ? (
                    posts.map((post) => (
                        <div key={post.id} className="post">
                            <h3>{post.title}</h3>
                            <p>{post.content}</p>
                            <div>Posted by: {post.author.username}</div>
                            {post.image && (
                                <div>
                                    <img src={post.image} alt={post.title} style={{maxWidth: "100%"}}/>
                                </div>
                            )}
                            {/* Additional post details and actions like edit or delete can go here */}
                        </div>
                    ))
                ) : (
                    <div className="no-posts-message">It looks like there are no posts :(</div>
                )}
            </div>


            <Modal
                // Modal for login/register alert
            >
                <Modal.Header closeButton>
                    <Modal.Title>Account Required</Modal.Title>
                </Modal.Header>
                <Modal.Body>You must be logged in to like a post. Please log in or create an account.</Modal.Body>
                <Modal.Footer>
                    <Button variant="primary" onClick={() => navigate('/login')}>
                        Login
                    </Button>
                    <Button variant="secondary" onClick={() => navigate('/register')}>
                        Register
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Home;
